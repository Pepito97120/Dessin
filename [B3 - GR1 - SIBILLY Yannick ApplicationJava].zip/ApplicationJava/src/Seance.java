import java.util.Date;
public class Seance {
	public Seance () {
		super();
	}
	public Seance(Seance Seance1) {
		
	}
	public Seance(Date date, Date heure, int duree) {
		
	}
	
}
