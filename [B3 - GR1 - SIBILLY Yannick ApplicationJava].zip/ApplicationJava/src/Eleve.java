
public class Eleve extends Personne {
	public Eleve() {
		super();
	}
	public Eleve(Eleve Eleve2){
		super(Eleve2);
	}
	public Eleve(String nom, String prenom, int age){
		super(nom, prenom, age);
	}
	@Override
	public void Function() {
		System.out.println("Je suis un �l�ve!!!");
	}
	@Override
	public void action() {
		// TODO Stub de la m�thode g�n�r� automatiquement
		System.out.println("Je suis des modules!");
	}
}
