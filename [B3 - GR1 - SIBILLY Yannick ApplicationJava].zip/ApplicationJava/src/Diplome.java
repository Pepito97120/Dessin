import java.util.ArrayList;

public class Diplome {
	private ArrayList<Diplome>  _Diplome;

	public ArrayList<Diplome> get_Diplome() {
		return _Diplome;
	}

	public void set_Diplome(ArrayList<Diplome> _Diplome) {
		this._Diplome = _Diplome;
	}
}
