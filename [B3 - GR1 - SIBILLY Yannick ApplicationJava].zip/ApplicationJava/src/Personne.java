
public abstract class Personne {
	private String _prenom, _nom;
	private int _age;
	//setters
	public void setNom(String nom) {
		this._nom = nom;
	}
	public void setPrenom(String prenom) {
		this._prenom = prenom.substring(0,1).toUpperCase() + prenom.substring(1, prenom.length()).toLowerCase();
	}
	public void setAge(int age) {
		this._age = age;
	}
	//getters
	
	public String getPrenom() {
		return this._prenom;
	}
	public int getAge() {
		return this._age;
	}
	public String getNom() {
		// TODO Stub de la m�thode g�n�r� automatiquement
		return this._nom;
	}
	//constructeurs
	public Personne() {
		this.setNom(" ");
		this.setPrenom(" ");
		this.setAge(0);
	}
	public Personne(Personne Pers) {
		this.setNom(Pers.getNom());
		this.setPrenom(Pers.getPrenom());
		this.setAge(Pers.getAge());
	}
	public Personne(String nom, String prenom, int age) {
		this.setNom(nom);
		this.setPrenom(prenom);
		this.setAge(age);
	}
	
	public void Function() {
		System.out.println("Je suis une personne lambda!!!");
	}
	public abstract void action();
	
	@Override //permet la surcharge d'une classe
	public String toString() {
		return this.getNom() + " " + this.getPrenom();
	}
	
	@Override
    public boolean equals(Object Pers) 
    {
        Personne personne = (Personne)Pers;

         if(this._nom.equals(personne.getNom()) && this._prenom.equals(personne.getPrenom()) && this._age == personne.getAge())
         {
             return true;
         } else {
        	 return false;
         }
    }
	
}


