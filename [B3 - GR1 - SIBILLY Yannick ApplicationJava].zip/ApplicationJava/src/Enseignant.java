import java.util.ArrayList;

public class Enseignant extends Personne {
	private String _prenom, _nom;
	private int _age;
	private int _anneeEmbauche;
	private ArrayList<Diplome>  _diplome;
	
	//constructeurs
	public Enseignant() {
		super();
	}
	public Enseignant(Enseignant Ens2){
		super(Ens2);
	}
	public Enseignant(String nom, String prenom, int age /*, ArrayList<Diplome> Diplome, int AnneeEmbauche*/){
		super(nom, prenom, age);
		//this.setDiplome(Diplome);
		//this.setAnneeEmbauche(AnneeEmbauche);
	}
	//getters
	
	public String getNom() {
		return this._nom;
	}
	public String getPrenom() {
		return this._prenom;
	}
	public int getAge() {
		return this._age;
	}
	public ArrayList<Diplome> getDiplome() {
		return this._diplome;
	}
	public int getAnneeDiplome() {
		return this._anneeEmbauche;
	}
	
	//setters
	
	public void setNom(String nom) {
		this._nom = nom;
	}
	public void setPrenom(String prenom) {
		this._prenom = prenom.substring(0,1).toUpperCase() + prenom.substring(1, prenom.length()).toLowerCase();
	}
	public void setAge(int age) {
		this._age = age;
	}
	public void setDiplome(ArrayList<Diplome> diplome) {
		this._diplome = diplome;
	}
	public void setAnneeEmbauche(int AnneeEmbauche){
		this._anneeEmbauche = AnneeEmbauche;
	}
	
	@Override
	public void Function() {
		System.out.println("Je suis un enseignant!");
	}
	@Override
	public void action() {
		// TODO Stub de la m�thode g�n�r� automatiquement
		System.out.println("Je donne des cours!");
	}
	
	//constructeurs enseigants
	/*
	public Enseignant(String nom, String prenom, int age) {
		this.setNom(nom);
		this.setPrenom(prenom);
		this.setAge(age);
	}*/
	
	
	
	
	
	
}
