
public class Directeur extends Personne{
	public Directeur() {
		super();
	}
	public Directeur(Directeur Dir) {
		super(Dir);
	}
	public Directeur (String nom, String prenom, int age) {
		super(nom,prenom,age);
	}
	@Override
	public void Function() {
		System.out.println("Je suis le directeur!!!");
	}
	@Override
	public void action() {
		// TODO Stub de la m�thode g�n�r� automatiquement
		
	}
}
