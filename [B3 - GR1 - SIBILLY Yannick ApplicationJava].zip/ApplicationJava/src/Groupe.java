
public class Groupe {
	public Groupe(String libelle) {
		
	}
}
