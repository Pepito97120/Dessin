

public class Module extends Seance {
	public Module() {
		
	}
	public Module (Module Module1){
		super(Module1);
	}
	public Module(int code, String libelle, int duree) {
		
	}
}
