import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Node;



public class Etablissement {
	private String _nom;
	private ArrayList<Personne> _personne;
	private Directeur _directeur;

	public Etablissement(String nom) {
		this._nom = nom;
		_directeur = new Directeur();
		_personne = new ArrayList<Personne>();
	}
	public Etablissement() {
		_directeur = new Directeur();
		_personne = new ArrayList<Personne>();
	}


	public String get_nom() {
		return _nom;
	}

	public void set_nom(String _nom) {
		this._nom = _nom;
	}

	public ArrayList<Personne> get_personne() {
		return _personne;
	}

	public void set_personne(ArrayList<Personne> _personne) {
		this._personne = _personne;
	}
	
	//coder une fonction qui s'appel importer() void
	//importe des informations d'un fichier xml, ou json. / ou avec une base de donn�e tables personnes et type li� par une CIF
	//il faut afficher les informations � l'�cran
	//on peut utiliser le principe de polymorphisme pour r�cup�rer les infos des enseignants, personnes etc.
	
	public void importer() 
    {
        File fichierXml = new File("C:\\Users\\Yannick\\workspace\\ApplicationJava\\src\\personne.xml"); //changer le chemin par votre chemin d'acc�s.
        List<String> lines = null;
        try{
        	lines = Files.readAllLines(fichierXml.toPath());
        }
        catch (final IOException e) {
            e.printStackTrace();
        } 

        for (String line : lines) 
        {
            String[] subLine = line.split(";");
            if (subLine.length == 4) 
            {
                switch (subLine[0]) 
                {
                case "Eleve":
                    Eleve newEleve = new Eleve(subLine[1], subLine[2], Integer.parseInt(subLine[3]) );
                    addPers(newEleve);
                    System.out.println("Bonjour, je suis " + newEleve.getNom() + " " + newEleve.getPrenom());
                    System.out.println("J'ai " + newEleve.getAge()+ " ans!");
                    newEleve.Function();
                    System.out.println("----------------------------------");
                    break;
                case "Enseignant":
                    Enseignant newEnseignant = new Enseignant(subLine[1], subLine[2], Integer.parseInt(subLine[3]) );
                    addPers(newEnseignant);
                    System.out.println("Bonjour, je suis " + newEnseignant.getNom() + " " + newEnseignant.getPrenom());
                    System.out.println("J'ai " + newEnseignant.getAge()+ " ans!");
                    newEnseignant.Function();
                    System.out.println("----------------------------------");
                    break;
                case "Delegue":
                    Delegue newDelegue = new Delegue(subLine[1], subLine[2], Integer.parseInt(subLine[3]) );
                    addPers(newDelegue);
                    System.out.println("Bonjour, je suis " + newDelegue.getNom() + " " + newDelegue.getPrenom());
                    System.out.println("J'ai " + newDelegue.getAge()+ " ans!");
                    newDelegue.Function();
                    System.out.println("----------------------------------");
                    break;
                case "Directeur":
                    Directeur newDirecteur = new Directeur(subLine[1], subLine[2], Integer.parseInt(subLine[3]) );
                    addPers(newDirecteur);
                    System.out.println("Bonjour, je suis " + newDirecteur.getNom() + " " + newDirecteur.getPrenom());
                    System.out.println("J'ai " + newDirecteur.getAge()+ " ans!");
                    newDirecteur.Function();
                    System.out.println("----------------------------------");
                    break;
                }
            }
            //System.out.println(subLine[0]);
        }
    }
	
	public void afficherListPers() {
		System.out.println("Affichage du personnel de l'�tablissement");
		for (Personne pers : _personne) {
			Class<? extends Personne> cls = pers.getClass();
			System.out.println(cls.getName() + " : " + pers.getPrenom() + " " + pers.getNom() + "Age : "+ pers.getAge() );
		}
	}

	private void addPers(Enseignant newEnseignant) {
		// TODO Stub de la m�thode g�n�r� automatiquement
		
	}
	private void addPers(Directeur newDirecteur) {
		// TODO Stub de la m�thode g�n�r� automatiquement
		
	}

	private void addPers(Eleve newEleve) {
		// TODO Stub de la m�thode g�n�r� automatiquement
		
	}
	
}
