
public class Delegue extends Eleve{
	public Delegue(String nom, String prenom, int age){
		super(nom, prenom, age);
	}
@Override
public void Function () {
	System.out.println("Je suis un d�l�gu�!!");
}
@Override
public void action() {
	// TODO Stub de la m�thode g�n�r� automatiquement
	super.action();
	System.out.println("Je fais des comptes rendus de r�union!");
	
}
}
