
public class Section {
	public Section(String nom) {
		
	}
}
