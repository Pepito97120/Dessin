import java.util.ArrayList;

public class Exercice {
	public static void main(String[] args) {
		
		Etablissement Etab = new Etablissement();
		Etab.afficherListPers();
		Etab.importer();
		
		//System.out.println();
		
	}
}
